using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra


function CalculTrapeze(robot,qi,qf,duree)
    q_point = [3.3,3.3,3.3,3.3,3.2,3.2];
    q_point_point = [30,30,30,30,30,30];
    t1 = zeros(6,1);
    tf = zeros(6,1);
    t2 = zeros(6,1);
    dq = zeros(6,1);
    qp = zeros(6,1);
    qp1 = zeros(6,1);
    qp2 = zeros(6,1);
    Param = Any[];

    for i in 1:1:6
    t1[i] = q_point[i] / q_point_point[i];
    #dq[i] = maximum(robot[i])-minimum(robot[i]);
    dq[i] = qf[i]-qi[i];
    tf[i] = ( dq[i] / q_point[i] ) + q_point[i] / q_point_point[i];
    t2[i] = tf[i]-t1[i];
    end
    tfinal = findmax(tf);
    t_final = tfinal[1];
    T_1 = zeros(6,1);
    T2 = zeros(6,1);

    for i in 1:1:6
        qp1[i] = ((t_final*q_point_point[i])+sqrt((t_final*q_point_point[i])^2-4*dq[i]*q_point_point[i]))/2;
        qp2[i] = ((t_final*q_point_point[i])-sqrt((t_final*q_point_point[i])^2-4*dq[i]*q_point_point[i]))/2;
        if (qp1[i] < q_point[i] && qp1[i]>=0)
            qp[i] = qp1[i];
        else
            if (qp2[i] < q_point[i] && qp2[i]>=0)
                qp[i] = qp2[i];
            end
        end
    end

    ## faire une boucle for pour T1 et l'envoyer dans calculQ => t1 = qp/qpp.

    for i in 1:1:6
        T_1[i] = qp[i]/q_point_point[i];
    end

    if (duree > t_final)
        t_final = duree;
        for i in 1:1:6
        T2[i] = t_final-T_1[i];
    end

    else
        duree = t_final;
        for i in 1:1:6
        T2[i] = t_final-T_1[i];
    end

    end

    push!(Param, T_1,T2,t_final,qi,qf,qp,q_point_point);

return Param;
end
