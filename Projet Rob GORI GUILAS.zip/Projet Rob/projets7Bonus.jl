using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra
using Gadfly

###################
# Loi polynomiale #
###################

############################
# Déclarations des éléments#
############################

Coeff = zeros(6,6);
Amax = 30;
tf = 2;
longueur = tf/0.001;
Qinit = [0;0;0;0;0;0];
Qfinal = [pi;pi/2;-pi;pi/4;pi/6;-pi/2];
t = 0:0.001:tf;
Coeff = [1 0 0 0 0 0; 0 1 0 0 0 0; 0 0 2 0 0 0; 1 tf tf^2 tf^3 tf^4 tf^5 ; 0 1 2*tf 3*(tf^2) 4*(tf^3) 5*(tf^4); 0 0 2 6*tf 12*(tf^2) 20*(tf^3)];
C = inv(Coeff);
R = zeros(6,6);
I = zeros(6,6);
global p = zeros(6,length(t));
global pp = zeros(6,length(t));
global ppp = zeros(6,length(t));

#for i in 1:6
#    I = [Qinit[i];0;Amax;Qfinal[i];0;-Amax];
#    R[:,i] = C*I;
#end

global Q = zeros(6,length(t));
global Qp = zeros(6,length(t));
global Qpp = zeros(6,length(t));
for t in 0:longueur
    for i in 1:6
        if (Qfinal[i] < 0)
            I = [Qinit[i];0;-Amax;Qfinal[i];0;Amax];
            R[:,i] = C*I;
        else
            I = [Qinit[i];0;Amax;Qfinal[i];0;-Amax];
            R[:,i] = C*I;
        end
        global Q[i,floor(Int,t+1)] = R[1,i]+R[2,i]*(t*0.001)+R[3,i]*((t*0.001)^2)+R[4,i]*((t*0.001)^3)+R[5,i]*((t*0.001)^4)+R[6,i]*((t*0.001)^5);
        global Qp[i,floor(Int,t+1)] = R[2,i]+2*R[3,i]*(t*0.001)+3*R[4,i]*((t*0.001)^2)+4*R[5,i]*((t*0.001)^3)+5*R[6,i]*((t*0.001)^4);
        global Qpp[i,floor(Int,t+1)] = 2*R[3,i] + 6*R[4,i]*(t*0.001)+12*R[5,i]*((t*0.001)^2)+20*R[6,i]*((t*0.001)^3);
        #global Q[:,floor(Int,t+1)] = Qinit + p[i]*(Qfinal-Qinit);
        #global Qp[:,floor(Int,t+1)] = pp[i]*(Qfinal-Qinit);
        #global Qpp[:, floor(Int,t+1)] = ppp[i]*(Qfinal-Qinit);

    end
end

pBonus =    Plots.plot(t, [Q[1,:] Q[2,:] Q[3,:] Q[4,:] Q[5,:] Q[6,:]],
            title = "Position",xlims = (0,tf), ylims = (-3*pi,pi) )
display(pBonus)
pBonus2 =   Plots.plot(t,
            [Qp[1,:] Qp[2,:] Qp[3,:] Qp[4,:] Qp[5,:] Qp[6,:]],
            title =  "Vitesse",xlims = (0,tf), ylims = (-3*pi,2*pi) )
display(pBonus2)
pBonus3 =   Plots.plot(t,
            [Qpp[1,:] Qpp[2,:] Qpp[3,:] Qpp[4,:] Qpp[5,:] Qpp[6,:]],
            title = "Accélération",xlims = (0,tf), ylims = (-Amax,Amax))
display(pBonus3)
