using IJulia
using Printf
using LaTeXStrings
using LinearAlgebra
using Plots
## Pour les valeurs négatives, on a décidé que le programme de plotTrapèze serait moins lourd si on mettait directement
##abs() pour Param[6] et Param[7]. En effet, on aurait pu rajouter des if et changer dans les cas cités ci-dessus,
##mais l'utilisation de abs() rend le code plus rapide, d'où son choix.
function PlotTrapeze(Param)
    t = 0:0.005:Param[3];
    vitesse = zeros(6,length(t));
    acceleration = zeros(6,length(t));
    position = zeros(6,length(t));

    for i in 1:1:6
        for j in 1:length(t)
            if (t[j]<= Param[1])
                vitesse[i,j] = t[j]*abs(Param[7][i]);
                acceleration[i,j] = abs(Param[7][i]);
                position[i,j] = 0.5*(t[j]^2)*(-Param[7][i]) + Param[4][i];

            elseif (t[j]> Param[1] && t[j]<=Param[2])

                vitesse[i,j] = abs(Param[6][i]);
                acceleration[i,j] = 0;
                position[i,j] = (t[j]-Param[1])*(-Param[6][i]) + 0.5*(Param[1]^2)*(-Param[7][i]) + Param[4][i];

            elseif (t[j]> Param[2] && t[j]<=Param[3])

                vitesse[i,j] = -abs(Param[7][i])*(t[j]-Param[2])+abs(Param[6][i]);
                acceleration[i,j] = -abs(Param[7][i]);
                position[i,j] = -0.5*((t[j]-Param[2])^2)*(-Param[7][i])+ (t[j]-Param[2])*(-Param[6][i]) + (Param[2]-Param[1])*(-Param[6][i])+0.5*(Param[1]^2)*(-Param[7][i]) + Param[4][i];

            end
        end

    end

p10 = Plots.plot(t,[vitesse[1,:] vitesse[2,:] vitesse[3,:] vitesse[4,:] vitesse[5,:] vitesse[6,:]], layout = 6, label = ["q1p" "q2p" "q3p" "q4p" "q5p" "q6p"])
display(p10)
p11 = Plots.plot(t,[position[1,:] position[2,:] position[3,:] position[4,:] position[5,:] position[6,:]], layout = 6, label = ["q1" "q2" "q3" "q4" "q5" "q6"])
display(p11)
p12 = Plots.plot(t,[acceleration[1,:] acceleration[2,:] acceleration[3,:] acceleration[4,:] acceleration[5,:] acceleration[6,:]], layout = 6, label = ["q1pp" "q2pp" "q3pp" "q4pp" "q5pp" "q6pp"])
display(p12)


end
