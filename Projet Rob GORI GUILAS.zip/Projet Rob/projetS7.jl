using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra
using Gadfly

include("affichage.jl")
include("CalculeTrapeze.jl")
include("CalculQ.jl")
include("ConnexionVREP.jl")
include("CalculModele.jl")
include("Cinematique.jl")

dt = 0.005
#declaration des paramètres DH
θ = zeros(6,1);
alpha = [0 -pi / 2 0 -pi / 2 pi / 2 -pi / 2]
d = [0 0 265.69 30 0 0]
theta = [θ[1] θ[2] - 1.4576453 θ[3] - 0.898549163 θ[4] θ[5] θ[6]]
r = [159 0 0 258 0 0]
p = [0; 0; 0; 1]

#Limites articulaires du robot
q1 = -pi : 0.01 : pi;
q2 = -pi/2 : 0.01:pi/2;
q3 = -pi/2 : 0.01: 3*pi/4;
q4 = -pi : 0.01 : pi;
q5 = -pi/2 : 0.01 : pi/2;
q6 = -pi : 0.01 : pi;
qi = [0.0,0.0,0.0,0.0,0.0,0.0];
qf = [-1,-1,-0.5,-0.5,-1,-1];

#Définition des valeurs d'accélérations et de vitesses de chaque articulation
q_point = [3.3,3.3,3.3,3.3,3.2,3.2];
q_point_point = [30,30,30,30,30,30];
Cmax = [44.2,44.2,21.142,21.142,6.3,6.3];
robot = Any[];
push!(robot, q1,q2,q3,q4,q5,q6);




#########################################################################
# On obtient la matrice de passage entre le repère et le bout du crayon #
#########################################################################
T01 = Matrice_passage(theta[1], alpha[1], r[1], d[1]);
T12 = Matrice_passage(theta[2], alpha[2], r[2], d[2]);
T23 = Matrice_passage(theta[3], alpha[3], r[3], d[3]);
T34 = Matrice_passage(theta[4], alpha[4], r[4], d[4]);
T45 = Matrice_passage(theta[5], alpha[5], r[5], d[5]);
T56 = Matrice_passage(theta[6], alpha[6], r[6], d[6]);
TF = T01 * T12 * T23 * T34 * T45 * T56;
position = MGD(TF, p);


##########################################################################################
# On crée une liste de matrice de passage de chaque articulation vers le repère initial  #
##########################################################################################
list = Any[];
push!(
    list,
    T01,
    T01 * T12,
    T01 * T12 * T23,
    T01 * T12 * T23 * T34,
    T01 * T12 * T23 * T34 * T45,
    TF,
);

TFD = TF;


listp = Any[];
for n = 1:1:6
    push!(listp, get_point(list, n))
end


listo = Any[];
for n = 1:1:6
    push!(listo, get_orientation(list, n))
end
AD = listo[6];

#affichage du robot et des repères de chaque articulation
affichage(listp,listo);

#Commande en trapbzez
Param = CalculeTrapeze(robot,qi,qf,1);

###temps = 0:0.1:Param[3];

#PATHVREP = "C:\\Users\\aurel\\Desktop\\MEAled\\rob"
#include("C:\\Users\\aurel\\Desktop\\MEAled\\rob\\VREP.jl");
#clientID = startsimulation(simx_opmode_oneshot)
#if clientID == 0
    #println("Connexion avec le serveur V-REP ok")
    #GetHandles(clientID, 6, simx_opmode_oneshot_wait, objectname_robotis)

#for t in 0:0.005:Param[3]
    #qtest = CalculQ(robot,Param,t);
    ##setjointposition(clientID, qtest, 6, 0, objectname_robotis)

### end

#stopsimulation(clientID, simx_opmode_oneshot) # Arrêt de la simulation
#else
#println("Erreur de connexion")
#end

#commande cinématique
J = Matrix{Float64}(undef, 6, 6)
J = Jacobi(list);
Jp = zeros(6,6);
Jp = pinv(J);
Pd = [600,1000,700];
AD = [1 0 0; 0 1 0; 0 0 1];
pas = 0.01;
K0 = 3;
KP = 3;
ωD = [1;1;1];
Pdp = [0;0;0];
global fin = 0;
global q = [0;0;0;0;0;0];
global Qqq = [0;0;0;0;0;0];
global listPE = Any[];
global listQn = Any[];


ConnexionVREP();

while fin != 1
    #global theta1 = zeros(6,1);
    #global theta1 = getjointposition(clientID, 6, 0, objectname_robotis)

    T01E = Matrice_passage(Qqq[1], alpha[1], r[1], d[1]);
    T12E = Matrice_passage(Qqq[2], alpha[2], r[2], d[2]);
    T23E = Matrice_passage(Qqq[3], alpha[3], r[3], d[3]);
    T34E = Matrice_passage(Qqq[4], alpha[4], r[4], d[4]);
    T45E = Matrice_passage(Qqq[5], alpha[5], r[5], d[5]);
    T56E = Matrice_passage(Qqq[6], alpha[6], r[6], d[6]);
    TFE = T01 * T12 * T23 * T34 * T45 * T56;
    global listE = Any[];
    push!(
        listE,
        T01E,
        T01E * T12E,
        T01E * T12E * T23E,
        T01E * T12E * T23E * T34E,
        T01E * T12E * T23E * T34E * T45E,
        TFE,
    );

    push!(listPE, listE[6]*[0;0;0;1])

    global listoE = Any[];
    for n = 1:1:6
        push!(listoE, get_orientation(listE, n))
    end
    global Qqq = Cinematique(listE,Pd,listoE,Qqq,AD,ωD,K0,KP,Pdp,Jp,pas)
    global q = Qqq;
    setjointposition(clientID,Qqq,6,0,objectname_robotis)
    simxSynchronousTrigger(clientID);
    push!(listQn, Qqq)
end
sleep(10)
stopsimulation(clientID, simx_opmode_oneshot) # Arrêt de la simulation
