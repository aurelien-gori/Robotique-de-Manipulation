using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra
using Gadfly

function ConnexionVREP()

dt = 0.005

PATHVREP = "C:\\Users\\aurel\\Desktop\\MEAled\\rob"
include("C:\\Users\\aurel\\Desktop\\MEAled\\rob\\VREP.jl");
clientID = startsimulation_trig(simx_opmode_oneshot,dt)
if clientID == 0
    println("Connexion avec le serveur V-REP ok")
    GetHandles(clientID, 6, simx_opmode_oneshot_wait, objectname_robotis)

    θcontrol = zeros(6)
    θcontrol[1] = pi/4
    θcontrol[2] = 0
    θcontrol[3] = 0
    θcontrol[4] = 0
    θcontrol[5] = 0
    θcontrol[6] = 0

    #setjointposition(clientID, θcontrol, 6, 0, objectname_robotis)
    # On vient lire le vecteur des positions articulaires du robot Robotis
    qread = getjointposition(clientID, 6, 0, objectname_robotis)

    # On affiche le vecteur des positions articulaires du robot Robotis
    println("theta=", qread * 360 / (2 * pi))

else
    println("Erreur de connexion")
end

end
