using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra
using Gadfly

include("CalculeTrapeze.jl")
include("CalculQ.jl")
include("ConnexionVREP.jl")
include("CalculModele.jl")

#################################
# Limites articulaires du robot #
#################################

q1 = -pi : 0.01 : pi;
q2 = -pi/2 : 0.01:pi/2;
q3 = -pi/2 : 0.01: 3*pi/4;
q4 = -pi : 0.01 : pi;
q5 = -pi/2 : 0.01 : pi/2;
q6 = -pi : 0.01 : pi;
qi = [0.0,0.0,0.0,0.0,0.0,0.0];
qf = [-1,-1,-0.5,-0.5,-1,-1];
################################################################################
# Définition des valeurs d'accélérations et de vitesses de chaque articulation #
################################################################################

q_point = [3.3,3.3,3.3,3.3,3.2,3.2];
q_point_point = [30,30,30,30,30,30];
Cmax = [44.2,44.2,21.142,21.142,6.3,6.3];
robot = Any[];
push!(robot, q1,q2,q3,q4,q5,q6);

#######################
# Commande en trapèze #
#######################

Param = CalculeTrapeze(robot,qi,qf,1);

temps = 0:0.1:Param[3];

ConnexionVREP();

for t in 0:0.005:Param[3]
    qtest = CalculQ(robot,Param,t);
    setjointposition(clientID, qtest, 6, 0, objectname_robotis)
    simxSynchronousTrigger(clientID);
end

sleep(10)
stopsimulation(clientID, simx_opmode_oneshot) # Arrêt de la simulation
