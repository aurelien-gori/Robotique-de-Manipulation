using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra

# 1ere etape ###########################################################################
# obtenir avec le mgd la matrice d'orientation de l'effecteur et sa position actuelle  #
# 2eme etape ###########################################################################
# en déduire l'erreur de suivi de trajectoire (epsilon)                                #
# déterminer L et oméga (opérateur de pre produit vectotriel => annexes)               #
# reclaculer la jaco pour chaque effecteur pour obtenir omegaD                         #
#a chaque itération, l'angle change donc listo et list changent => penser à les update #
########################################################################################

function Cinematique_position(listE,Pd,Pdp,KP)
    TF  = listE[6];
    global PE = TF[1:3,4];
    ϵP = Pd-PE;
    PEp= Pdp+KP*ϵP;

    return PEp;
end

function Cinematique_orientation(listoE,AD,ωD,K0)
    AE = zeros(3,3);
    A  = zeros(3,3);
    ϵ0 = zeros(3,1);
    global L  = zeros(3,3);
    ωE = zeros(3,3);

    AE = listoE[6];
    A  = AD*transpose(AE);

    ϵ0[1] = 0.5*(A[6]-A[8]);
    ϵ0[2] = 0.5*(A[7]-A[3]);
    ϵ0[3] = 0.5*(A[2]-A[4]);

    global L  = -0.5*(S(AD[:,1])*S(AE[:,1])+S(AD[:,2])*S(AE[:,2])+S(AD[:,3])*S(AE[:,3]));
    ωE = inv(L)*(ϵ0*K0+transpose(L)*ωD);

#    QP = zeros(6,1);
#    QP = Jp*E;
#    QC = zeros(6,1);
#    QC = q + QP*t;

    return ωE;
end

function S(b)
    Vect = zeros(3,3);
    Vect[1] = 0;
    Vect[2] = b[3];
    Vect[3] = -b[2];
    Vect[4] = -b[3];
    Vect[5] = 0;
    Vect[6]= b[1];
    Vect[7] = b[2];
    Vect[8] = -b[1];
    Vect[9] = 0;
    return Vect;
end
