using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra



function CalculQ(robot, Param, t)
    q = zeros(6,1);
for i in 1:1:6
    if (t <= Param[1] && t >= 0)
        q[i] = 0.5 * Param[7][i] * t^2 + Param[4][i];

    elseif (t >= Param[1] && t <= Param[2])
        q[i] = Param[6][i]*(t - Param[1]) + 0.5 * Param[7][i] * Param[1]^2 + Param[4][i];

    elseif (t > Param[2] && t <= Param[3])
        q[i] = -0.5 * Param[7][i] * (t - Param[2])^ 2 + Param[6][i]*(t - Param[2]) + Param[6][i] * (Param[2] - Param[1]) + 0.5 * Param[7][i] * Param[1]^2 + Param[4][i];

    end
end
    return q;
end
