using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra

include("Cinematique.jl")
include("CalculModele.jl")
include("affichage.jl")

########################
# Commande cinématique #
########################

global J = Matrix{Float64}(undef, 6, 6)
global Jp = Matrix{Float64}(undef, 3, 6)
global Jo = Matrix{Float64}(undef, 3, 6)

θ = zeros(6,1);
alpha_ = [0 -pi / 2 0 -pi / 2 pi / 2 -pi / 2]
d_ = [0 0 265.69 30 0 0]
theta = [θ[1] θ[2] - 1.4576453 θ[3] - 0.898549163 θ[4] θ[5] θ[6]]
r_ = [159 0 0 258 0 0]
Qinit = [0;0;0;0;0;0]

T01E = Matrice_passage(Qinit[1], alpha_[1], r_[1], d_[1]);
T12E = Matrice_passage(Qinit[2], alpha_[2], r_[2], d_[2]);
T23E = Matrice_passage(Qinit[3], alpha_[3], r_[3], d_[3]);
T34E = Matrice_passage(Qinit[4], alpha_[4], r_[4], d_[4]);
T45E = Matrice_passage(Qinit[5], alpha_[5], r_[5], d_[5]);
T56E = Matrice_passage(Qinit[6], alpha_[6], r_[6], d_[6]);
TFE = T01E * T12E * T23E * T34E * T45E * T56E;

global listE = Any[];
push!(
    listE,
    T01E,
    T01E * T12E,
    T01E * T12E * T23E,
    T01E * T12E * T23E * T34E,
    T01E * T12E * T23E * T34E * T45E,
    TFE,
);

global J = Jacobi(listE,TFE[1:3,4]);
global Jp = [J[1,:] J[2,:] J[3,:]];
global Jo = [J[4,:] J[5,:] J[6,:]];

global Jop = pinv(Jo);
global Jpp = pinv(Jp);

Pd = [600,0,800];
AD = [1 0 0; 0 1 0; 0 0 1];
pas = 0.01;
K0 = 3;
KP = 3;
ωD = [1;1;1];
Pdp = [0;0;0];

t = 0:0.01:10;
global Qcpo  = zeros(6,length(t));
global Qcpp = zeros(6,length(t));
global Qcpp_actuel = zeros(6,1);
global  Qcpo_actuel = zeros(6,1);
global listPE = Any[];
global listQn = Any[];
#ConnexionVREP();

for i in 0:0.01:10

    T01E = Matrice_passage(Qcpp_actuel[1], alpha_[1], r_[1], d_[1]);
    T12E = Matrice_passage(Qcpp_actuel[2], alpha_[2], r_[2], d_[2]);
    T23E = Matrice_passage(Qcpp_actuel[3], alpha_[3], r_[3], d_[3]);
    T34E = Matrice_passage(Qcpp_actuel[4], alpha_[4], r_[4], d_[4]);
    T45E = Matrice_passage(Qcpp_actuel[5], alpha_[5], r_[5], d_[5]);
    T56E = Matrice_passage(Qcpp_actuel[6], alpha_[6], r_[6], d_[6]);
    TFE = T01E * T12E * T23E * T34E * T45E * T56E;

    global listE = Any[];
    push!(
        listE,
        T01E,
        T01E * T12E,
        T01E * T12E * T23E,
        T01E * T12E * T23E * T34E,
        T01E * T12E * T23E * T34E * T45E,
        TFE,
    );

    listp = Any[];
    for n = 1:1:6
        push!(listp, get_point(listE, n))
    end


    listo = Any[];
    for n = 1:1:6
        push!(listo, get_orientation(listE, n))
    end
    #affichage(listp,listo)
    global J = Jacobi(listE,TFE[1:3,4]);
    global Jp = transpose([J[1,:] J[2,:] J[3,:]]);
    global Jo = transpose([J[4,:] J[5,:] J[6,:]]);

    global Jop = pinv(Jo);
    global Jpp = pinv(Jp);

    push!(listPE, listE[6]*[0;0;0;1])
    global listoE = Any[];
    for n = 1:1:6
        push!(listoE, get_orientation(listE, n))
    end

    global Qcpp[:,floor(Int,i/0.01+1)] = Jpp*Cinematique_position(listE,Pd,Pdp,KP);
    global Qcpp[:,floor(Int,i/0.01+1)] = Qcpp[:,floor(Int,i/0.01+1)]*i+Qcpp_actuel;
    global Qcpp_actuel = Qcpp[:,floor(Int,i/0.01+1)];
end

p_Position = Plots.plot(t,[Qcpp[1,:] Qcpp[2,:] Qcpp[3,:] Qcpp[4,:] Qcpp[5,:] Qcpp[6,:]], layout = 6,
             label = ["position 1" "position 2" "position 3" "position 4" "position 5" "position 6"])
display(p_Position)

global pas = 0.1
for i in 0:pas:10

    T01E = Matrice_passage(Qcpo_actuel[1], alpha_[1], r_[1], d_[1]);
    T12E = Matrice_passage(Qcpo_actuel[2], alpha_[2], r_[2], d_[2]);
    T23E = Matrice_passage(Qcpo_actuel[3], alpha_[3], r_[3], d_[3]);
    T34E = Matrice_passage(Qcpo_actuel[4], alpha_[4], r_[4], d_[4]);
    T45E = Matrice_passage(Qcpo_actuel[5], alpha_[5], r_[5], d_[5]);
    T56E = Matrice_passage(Qcpo_actuel[6], alpha_[6], r_[6], d_[6]);
    TFE = T01E * T12E * T23E * T34E * T45E * T56E;

    global listE = Any[];
    push!(
        listE,
        T01E,
        T01E * T12E,
        T01E * T12E * T23E,
        T01E * T12E * T23E * T34E,
        T01E * T12E * T23E * T34E * T45E,
        TFE,
    );

    listp = Any[];
    for n = 1:1:6
        push!(listp, get_point(listE, n))
    end


    listo = Any[];
    for n = 1:1:6
        push!(listo, get_orientation(listE, n))
    end
    #affichage(listp,listo)
    global J = Jacobi(listE,TFE[1:3,4]);

    push!(listPE, listE[6]*[0;0;0;1])
    global listoE = Any[];
    for n = 1:1:6
        push!(listoE, get_orientation(listE, n))
    end
    Qcp = [Cinematique_position(listE,Pd,Pdp,KP);Cinematique_orientation(listoE,AD,ωD,K0)];
    global Qcpo[:,floor(Int,i/pas+1)] = pinv(J)*Qcp;
    global  Qcp_actuel =  Qcpo[:,floor(Int,i/pas+1)];
    global Qcpo[:,floor(Int,i/pas+1)] = Qcpo[:,floor(Int,i/pas+1)]*i+Qcp_actuel;
end

p_Orientation = Plots.plot(t,[Qcpo[1,:] Qcpo[2,:] Qcpo[3,:] Qcpo[4,:] Qcpo[5,:] Qcpo[6,:]], layout = 6,
             label = ["Orientation 1" "Orientation 2" "Orientation 3" "Orientation 4" "Orientation 5" "Orientation 6"])
display(p_Orientation)
