using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra
using Gadfly

###############################################################################
# On crée la fonction qui calcule la Matrice de passage d'un repère à l'autre #
###############################################################################

function Matrice_passage(theta, alpha, r, d)

    return [
        cos(theta) -sin(theta) 0 d
        cos(alpha)*sin(theta) cos(alpha)*cos(theta) -sin(alpha) -r*sin(alpha)
        sin(alpha)*sin(theta) sin(alpha)*cos(theta) cos(alpha) r*cos(alpha)
        0 0 0 1
    ]

end


###########################################
# On crée la fonction qui calcule le MGD  #
###########################################

function MGD(TF, p)
    return TF * p
end


#n = 1;
function get_point(list, n)
    return [list[n][13] list[n][14] list[n][15] 1]
end

function get_orientation(list, n)
    return [
        list[n][1] list[n][2] list[n][3]
        list[n][5] list[n][6] list[n][7]
        list[n][9] list[n][10] list[n][11]
    ]
end

function Jacobienne(list,p,i)
    O = zeros(3,1);
    O[1] = list[i][13];
    O[2] = list[i][14];
    O[3] = list[i][15];
    OP = zeros(3,1);
    for j in 1:1:3
        OP[j] = p[j]-O[j];
    end
    a = zeros(3,1);
    a[1] = list[i][9];
    a[2] = list[i][10];
    a[3] = list[i][11];

    CS = zeros(3,1);
    CS[1] = a[2]*OP[3]-a[3]*OP[2];
    CS[2] = a[3]*OP[1]-a[1]*OP[3];
    CS[3] = a[1]*OP[2]-a[2]*OP[1];

    J = zeros(6,1);
    J[1]= CS[1];
    J[2]= CS[2];
    J[3]= CS[3];
    J[4]= a[1];
    J[5]= a[2];
    J[6]= a[3];
    return J;
end

function Jacobi(list)
    global jacoGeo = zeros(6, 1)
    J = Matrix{Float64}(undef, 6, 6)
    p = (1, 1, 1)
    for i = 1:1:6
        global jacoGeo = Jacobienne(list, p, i)
        if (i == 1)
            J[1] = jacoGeo[1]
            J[2] = jacoGeo[2]
            J[3] = jacoGeo[3]
            J[4] = jacoGeo[4]
            J[5] = jacoGeo[5]
            J[6] = jacoGeo[6]
        elseif (i == 2)
            J[7] = jacoGeo[1]
            J[8] = jacoGeo[2]
            J[9] = jacoGeo[3]
            J[10] = jacoGeo[4]
            J[11] = jacoGeo[5]
            J[12] = jacoGeo[6]
        elseif (i == 3)
            J[13] = jacoGeo[1]
            J[14] = jacoGeo[2]
            J[15] = jacoGeo[3]
            J[16] = jacoGeo[4]
            J[17] = jacoGeo[5]
            J[18] = jacoGeo[6]
        elseif (i == 4)
            J[19] = jacoGeo[1]
            J[20] = jacoGeo[2]
            J[21] = jacoGeo[3]
            J[22] = jacoGeo[4]
            J[23] = jacoGeo[5]
            J[24] = jacoGeo[6]
        elseif (i == 5)
            J[25] = jacoGeo[1]
            J[26] = jacoGeo[2]
            J[27] = jacoGeo[3]
            J[28] = jacoGeo[4]
            J[29] = jacoGeo[5]
            J[30] = jacoGeo[6]
        elseif (i == 6)
            J[31] = jacoGeo[1]
            J[32] = jacoGeo[2]
            J[33] = jacoGeo[3]
            J[34] = jacoGeo[4]
            J[35] = jacoGeo[5]
            J[36] = jacoGeo[6]
        end

    end
    return J;
end
