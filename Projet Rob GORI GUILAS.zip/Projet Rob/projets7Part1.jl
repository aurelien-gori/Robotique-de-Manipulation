using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra
using Gadfly

include("affichage.jl")
include("CalculModele.jl")

#################################
# Déclaration des paramètres DH #
#################################

θ = zeros(6,1);
alpha = [0 -pi / 2 0 -pi / 2 pi / 2 -pi / 2]
d = [0 0 265.69 30 0 0]
theta = [θ[1] θ[2] - 1.4576453 θ[3] - 0.898549163 θ[4] θ[5] θ[6]]
r = [159 0 0 258 0 0]
p = [0; 0; 0; 1]

#########################################################################
# On obtient la matrice de passage entre le repère et le bout du crayon #
#########################################################################

T01 = Matrice_passage(theta[1], alpha[1], r[1], d[1]);
T12 = Matrice_passage(theta[2], alpha[2], r[2], d[2]);
T23 = Matrice_passage(theta[3], alpha[3], r[3], d[3]);
T34 = Matrice_passage(theta[4], alpha[4], r[4], d[4]);
T45 = Matrice_passage(theta[5], alpha[5], r[5], d[5]);
T56 = Matrice_passage(theta[6], alpha[6], r[6], d[6]);
TF = T01 * T12 * T23 * T34 * T45 * T56;
position = MGD(TF, p);

##########################################################################################
# On crée une liste de matrice de passage de chaque articulation vers le repère initial  #
##########################################################################################

list = Any[];
push!(
    list,
    T01,
    T01 * T12,
    T01 * T12 * T23,
    T01 * T12 * T23 * T34,
    T01 * T12 * T23 * T34 * T45,
    TF,
);

TFD = TF;

listp = Any[];
for n = 1:1:6
    push!(listp, get_point(list, n))
end

listo = Any[];
for n = 1:1:6
    push!(listo, get_orientation(list, n))
end
AD = listo[6];

############################################################
# Affichage du robot et des repères de chaque articulation #
############################################################

affichage(listp,listo);
