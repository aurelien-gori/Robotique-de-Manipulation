using IJulia
using Printf
using LaTeXStrings
using LinearAlgebra
using Plots

include("PlotTrapeze.jl")

function CalculeTrapeze(robot,qi,qf,duree)
    rob = robot;
    qp = [3.3,3.3,3.3,3.3,3.2,3.2];
    qpp = [30.0,30.0,30.0,30.0,30.0,30.0];
    dq = zeros(6,1);
    t1 = zeros(6,1);
    tf = zeros(6,1);
    for i in 1:1:6
        dq[i] = qf[i]-qi[i];
        t1[i] = qp[i]/qpp[i];
        tf[i] = dq[i]/qp[i] .+ t1[i];
    end
    tfmax = findmax(tf)[1];
    t1min = findmin(t1)[1];

    Param = Any[];
    for i in 1:1:6
        if (tf[i]< tfmax)
            t1[i] = t1min;
            tf[i] = tfmax;
        end

        if (duree > tfmax)
            tfmax = duree;
        else
            duree = tfmax;
        end

    end

    #push!(Param, t1min,tfmax-t1min,tfmax,qi,qf,qp,qpp)
    #qinew = CalculQ(rob,Param,0);
    #qfnew = CalculQ(rob,Param,tfmax);
    qpnew = zeros(6,1);
    qppnew = zeros(6,1);
    for i in 1:1:6
        #qpnew[i] = (qfnew[i]-qinew[i])/(tfmax-t1min);
        #qppnew[i] = qpnew[i]/t1min;
        qpnew[i] = abs(dq[i]/(tfmax-t1min));
        qppnew[i] = abs(qpnew[i]/t1min);
    end


    push!(Param, t1min,tfmax-t1min,tfmax,qi,qf,qpnew,qppnew)
    PlotTrapeze(Param);
    return Param;

end
