using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra


include("relier.jl")

function affichage(listp,listo)

    p1 = plot3d(title = "Axes des articulations",xlims = (-300,500), ylims = (-400,400), zlims = (0,800))

listx = Any[];
listy = Any[];
listz = Any[];


i = 1;
j = 1;


    push!(listx, [listp[i][1], listp[i][1] + listo[i][1]*50])
    push!(listy, [listp[i][2], listp[i][2] + listo[i][2]*50])
    push!(listz, [listp[i][3], listp[i][3] + listo[i][3]*50])


    p2 = plot3d!(listx[j], listy[j], listz[j], linewidth = 2.0, color = [:red],label = "x1")




    push!(listx, [listp[i][1], listp[i][1] + listo[i][4]*50])
    push!(listy, [listp[i][2], listp[i][2] + listo[i][5]*50])
    push!(listz, [listp[i][3], listp[i][3] + listo[i][6]*50])


    p3 = plot3d!(listx[j+1], listy[j+1], listz[j+1], linewidth = 2.0, color = [:green],label = "y1")





    push!(listx, [listp[i][1], listp[i][1] + listo[i][7]*50])
    push!(listy, [listp[i][2], listp[i][2] + listo[i][8]*50])
    push!(listz, [listp[i][3], listp[i][3] + listo[i][9]*50])


    p4 = plot3d!(listx[j+2], listy[j+2], listz[j+2], linewidth = 2.0, color = [:blue],label = "z1")


    i = 2;
    j = 4;


        push!(listx, [listp[i][1], listp[i][1] + listo[i][1]*50])
        push!(listy, [listp[i][2], listp[i][2] + listo[i][2]*50])
        push!(listz, [listp[i][3], listp[i][3] + listo[i][3]*50])


        p5 = plot3d!(listx[j], listy[j], listz[j], linewidth = 2.0, color = [:red],label = "x2")




        push!(listx, [listp[i][1], listp[i][1] + listo[i][4]*50])
        push!(listy, [listp[i][2], listp[i][2] + listo[i][5]*50])
        push!(listz, [listp[i][3], listp[i][3] + listo[i][6]*50])



        p6 = plot3d!(listx[j+1], listy[j+1], listz[j+1], linewidth = 2.0, color = [:green],label = "y2")




        push!(listx, [listp[i][1], listp[i][1] + listo[i][7]*50])
        push!(listy, [listp[i][2], listp[i][2] + listo[i][8]*50])
        push!(listz, [listp[i][3], listp[i][3] + listo[i][9]*50])



        p7 = plot3d!(listx[j+2], listy[j+2], listz[j+2], linewidth = 2.0, color = [:blue],label = "z2")



        i = 3;
        j =7;



            push!(listx, [listp[i][1], listp[i][1] + listo[i][1]*50])
            push!(listy, [listp[i][2], listp[i][2] + listo[i][2]*50])
            push!(listz, [listp[i][3], listp[i][3] + listo[i][3]*50])


            p8 = plot3d!(listx[j], listy[j], listz[j], linewidth = 2.0, color = [:red],label = "x3")




            push!(listx, [listp[i][1], listp[i][1] + listo[i][4]*50])
            push!(listy, [listp[i][2], listp[i][2] + listo[i][5]*50])
            push!(listz, [listp[i][3], listp[i][3] + listo[i][6]*50])



            p9 = plot3d!(listx[j+1], listy[j+1], listz[j+1], linewidth = 2.0, color = [:green],label = "y3")





            push!(listx, [listp[i][1], listp[i][1] + listo[i][7]*50])
            push!(listy, [listp[i][2], listp[i][2] + listo[i][8]*50])
            push!(listz, [listp[i][3], listp[i][3] + listo[i][9]*50])



            p10= plot3d!(listx[j+2], listy[j+2], listz[j+2], linewidth = 2.0, color = [:blue],label = "z3")


            i = 4;
            j = 10;


                push!(listx, [listp[i][1], listp[i][1] + listo[i][1]*50])
                push!(listy, [listp[i][2], listp[i][2] + listo[i][2]*50])
                push!(listz, [listp[i][3], listp[i][3] + listo[i][3]*50])


                p11 = plot3d!(listx[j], listy[j], listz[j], linewidth = 2.0, color = [:red],label = "x4")




                push!(listx, [listp[i][1], listp[i][1] + listo[i][4]*50])
                push!(listy, [listp[i][2], listp[i][2] + listo[i][5]*50])
                push!(listz, [listp[i][3], listp[i][3] + listo[i][6]*50])


                p12 = plot3d!(listx[j+1], listy[j+1], listz[j+1], linewidth = 2.0, color = [:green],label = "y4")





                push!(listx, [listp[i][1], listp[i][1] + listo[i][7]*50])
                push!(listy, [listp[i][2], listp[i][2] + listo[i][8]*50])
                push!(listz, [listp[i][3], listp[i][3] + listo[i][9]*50])



                p13 = plot3d!(listx[j+2], listy[j+2], listz[j+2], linewidth = 2.0, color = [:blue],label = "z4")


                j = 13;
                i = 5;




                    push!(listx, [listp[i][1], listp[i][1] + listo[i][1]*50])
                    push!(listy, [listp[i][2], listp[i][2] + listo[i][2]*50])
                    push!(listz, [listp[i][3], listp[i][3] + listo[i][3]*50])


                    p14 = plot3d!(listx[j], listy[j], listz[j], linewidth = 2.0, color = [:red],label = "x5")




                    push!(listx, [listp[i][1], listp[i][1] + listo[i][4]*50])
                    push!(listy, [listp[i][2], listp[i][2] + listo[i][5]*50])
                    push!(listz, [listp[i][3], listp[i][3] + listo[i][6]*50])



                    p15 = plot3d!(listx[j+1], listy[j+1], listz[j+1], linewidth = 2.0, color = [:green],label = "y5")





                    push!(listx, [listp[i][1], listp[i][1] + listo[i][7]*50])
                    push!(listy, [listp[i][2], listp[i][2] + listo[i][8]*50])
                    push!(listz, [listp[i][3], listp[i][3] + listo[i][9]*50])


                    p16 = plot3d!(listx[j+2], listy[j+2], listz[j+2], linewidth = 2.0, color = [:blue],label = "z5")


                    j = 16;
                    i = 6;


                        push!(listx, [listp[i][1], listp[i][1] + listo[i][1]*50])
                        push!(listy, [listp[i][2], listp[i][2] + listo[i][2]*50])
                        push!(listz, [listp[i][3], listp[i][3] + listo[i][3]*50])


                        p17 = plot3d!(listx[j], listy[j], listz[j], linewidth = 2.0, color = [:red],label = "x6")




                        push!(listx, [listp[i][1], listp[i][1] + listo[i][4]*50])
                        push!(listy, [listp[i][2], listp[i][2] + listo[i][5]*50])
                        push!(listz, [listp[i][3], listp[i][3] + listo[i][6]*50])



                        p18 = plot3d!(listx[j+1], listy[j+1], listz[j+1], linewidth = 2.0, color = [:green],label = "y6")





                        push!(listx, [listp[i][1], listp[i][1] + listo[i][7]*50])
                        push!(listy, [listp[i][2], listp[i][2] + listo[i][8]*50])
                        push!(listz, [listp[i][3], listp[i][3] + listo[i][9]*50])



                        p19 = plot3d!(listx[j+2], listy[j+2], listz[j+2], linewidth = 2.0, color = [:blue],label = "z6")
                        display(p19)


relierp(listp);

end
