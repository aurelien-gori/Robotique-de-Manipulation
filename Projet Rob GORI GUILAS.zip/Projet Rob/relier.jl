using IJulia
using Printf
using Plots
using LaTeXStrings
using LinearAlgebra
using Gadfly

function relierp(listp)
lists1 = Any[];
lists2 = Any[];
lists3 = Any[];

k = 1;
push!(lists1, [listp[k][1], listp[k+1][1]])
push!(lists2, [listp[k][2], listp[k+1][2]])
push!(lists3, [listp[k][3], listp[k+1][3]])
p20 = plot3d!(lists1[k], lists2[k], lists3[k], color = [:black], linewidth = 2.0,label = "");
display(p20);

k = 2;
push!(lists1, [listp[k][1], listp[k+1][1]])
push!(lists2, [listp[k][2], listp[k+1][2]])
push!(lists3, [listp[k][3], listp[k+1][3]])
p21 = plot3d!(lists1[k], lists2[k], lists3[k], color = [:black], linewidth = 2.0,label = "");
display(p21)

k = 3;
push!(lists1, [listp[k][1], listp[k+1][1]])
push!(lists2, [listp[k][2], listp[k+1][2]])
push!(lists3, [listp[k][3], listp[k+1][3]])
p22 = plot3d!(lists1[k], lists2[k], lists3[k], color = [:black], linewidth = 2.0,label = "");
display(p22)

k = 4;
push!(lists1, [listp[k][1], listp[k+1][1]])
push!(lists2, [listp[k][2], listp[k+1][2]])
push!(lists3, [listp[k][3], listp[k+1][3]])
p23 = plot3d!(lists1[k], lists2[k], lists3[k], color = [:black], linewidth = 2.0,label = "");
display(p23)

k = 5;
push!(lists1, [listp[k][1], listp[k+1][1]])
push!(lists2, [listp[k][2], listp[k+1][2]])
push!(lists3, [listp[k][3], listp[k+1][3]])
p24 = plot3d!(lists1[k], lists2[k], lists3[k], color = [:black], linewidth = 2.0,label = "");
display(p24)

end
